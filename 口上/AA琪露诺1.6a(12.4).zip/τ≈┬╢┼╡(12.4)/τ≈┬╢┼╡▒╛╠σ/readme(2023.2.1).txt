各位好啊，这里是国人作者破空（5419yf）
因为即将整合，所以将这个版本上传到各个论坛供各位下载
1.35B版本是这两年以来的一切的结晶……相比于1.0，1.1，1.2等已经成为历史的版本添加及删减了许多东西
删除了累赘的代码和口上片段，ooc的内容，以及曾经挪移的其他口上的文本（在1.2Fixed版本得以实现
相较于1.2版本，也增加了一定程度上的日常系
希望可以为各位的游玩体验起到一定程度上的提升

下一次更新是今年四月前，三月底
预测这也将是最后一个版本…以前自己画的饼也快填满了
已经完成了80%的内容，还剩下的是：开朗系转折事件，未完善的女仆系，日记（写了，但是因为代码问题暂未实装），以及二周目相关内容
感谢各位一直以来的陪伴，以及帮助我找出问题的各位……

本口上存在AA，所以十分推荐在游玩之前安装"saitamaar"字体
或多或少可以为游玩体验产生一些提升吧……
;感谢天空录在AA字符画方面的疑难解答
;一切AA来源来自https://aa.yaruyomi.com/ 路径为/た行/と/東方project/紅魔郷/チルノ
;一切AA使用于非商业性用途，如有相关侵权，我(作者破空)将在24小时内删除相关内容


Hello everyone, this is the Chinese author 破空 (5419yf)
Because of the upcoming integration, this version is uploaded to various forums for everyone to download
Version 1.35B is the culmination of everything in the last two years... Many things have been added and removed from the versions that have become history, such as 1.0, 1.1, 1.2, etc
Removed cumbersome code and oral fragments, ooc content, and other oral text that had been moved (implemented in 1.2Fixed)
Compared to version 1.2, it also adds a certain amount of daily systems
I hope it can improve your play experience to some extent

The next update will be by April this year, by the end of March
It is predicted that this will also be the last edition... The pie I drew before is almost full
80% of the content has been completed, the remaining items are: the Cheerful Twist, the incomplete Maid, the Diary (written, but not yet implemented due to code issues), and the two Weeks related content
Thank you for your company and for helping me figure it out...

AA exists on this port, so it is highly recommended to install the font "saitamaar" before playing
More or less, it can improve the experience...
; Thanks for “天空录” on AA character painting
; All sources of AA from https://aa.yaruyomi.com/ 路径为/た行/と/東方project/紅魔郷/チルノ
; All AA is used for non-commercial purposes. If there is any infringement, I (the author) will delete the relevant content within 24 hours


*機械翻訳で申し訳ありません

皆さん、こんにちは、これは中国作家が破空(5419yf)
今後の統合のため、このバージョンはさまざまなフォーラムにアップロードされ、誰でもダウンロードできます
バージョン1.35 bは、過去2年間のすべての集大成です…1.0、1.1、1.2など、ヒストリーとなったバージョンからは、多くのことが追加されたり削除されたりしています
移動された煩雑なコードおよび口上の断片、oocコンテンツなどの口上テキストを削除する(1.2 fixedで実装)
バージョン1.2と比較して、毎日のシステムの一定量を追加します
あなたのプレイ体験がある程度向上することを願っています

次回のアップデートは今年4月、3月末の予定です
これも最終回になると予想されていますが…。前に描いたパイはほとんど満腹です
内容の80%はすでに完成して、残りの項目は:陽気なツイスト、未完成のメイド、日記(書かれていますが、コードの問題のためにまだ実行されていません)、および2周間関連の内容です
あなたの会社に感謝し、それを理解するのを助けてくれて…

aaはこのポートに存在するので、再生する前に"saitamaar"フォントをインストールすることを強くお勧めします
多かれ少なかれ、それは経験を向上させることができます…
でaaキャラクターのトラブルシューティングありがとうございました
全てのリソースはウェブサイトhttps://aa.yaruyomi.comのパス/た行/と/東方project/紅魔郷/チルノから来ています
ですべてのaaは非営利目的で使用されます。著作権侵害があれば、私(作者破空)は24時間以内に該当コンテンツを削除します

ついでに、アンチ辞書処理した日本版を作ってみました……翻訳はありませんが
処理が必要なバージョンの場合は、同じフォルダ内の「日化」ファイルを伸張します。